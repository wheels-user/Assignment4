package assignment4;

import java.util.*;

public class TFComparator implements Comparator<ProfessorInfo> {
	private String[] keys;

	public TFComparator(String[] keys) {
		this.keys = keys;
	}

	@Override
	public int compare(ProfessorInfo o1, ProfessorInfo o2) {
		// TODO Auto-generated method stub
		int TF1 = 0, TF2 = 0;
		
		for (String key : keys) {
			String educationBackground1 = o1.getEducationBackground().toLowerCase();
			String researchInterests1 = o1.getResearchInterests().toLowerCase();
			String educationBackground2 = o2.getEducationBackground().toLowerCase();
			String researchInterests2 = o2.getResearchInterests().toLowerCase();
			
			while (educationBackground1.contains(key)) {
				TF1++;
				educationBackground1 = educationBackground1.substring(educationBackground1.indexOf(key)+key.length());
			}
			while (researchInterests1.contains(key)) {
				TF1++;
				researchInterests1 = researchInterests1.substring(researchInterests1.indexOf(key)+key.length());
			}
			while (educationBackground2.contains(key)) {
				TF2++;
				educationBackground2 = educationBackground2.substring(educationBackground2.indexOf(key)+key.length());
			}
			while (researchInterests2.contains(key)) {
				TF2++;
				researchInterests2 = researchInterests2.substring(researchInterests2.indexOf(key)+key.length());
			}
		}

		return TF2 - TF1;
	}

}
