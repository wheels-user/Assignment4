package assignment4;

public class ProfessorInfo {
	private String name;
	private String educationBackground;
	private String researchInterests;
	private String email;
	private String phone;
	
	public ProfessorInfo(String name, String educationBackground, String researchInterests, String email,
			String phone) {
		super();
		this.name = name;
		this.educationBackground = educationBackground;
		this.researchInterests = researchInterests;
		this.email = email;
		this.phone = phone;
	}

	@Override
	public String toString() {
		return "name: " + name + "\neducationBackground: " + educationBackground + "\nresearchInterests:"
				+ researchInterests + "\nemail: " + email + "\nphone: " + phone;
	}

	public String getName() {
		return name;
	}

	public String getEducationBackground() {
		return educationBackground;
	}

	public String getResearchInterests() {
		return researchInterests;
	}

	public String getEmail() {
		return email;
	}

	public String getPhone() {
		return phone;
	}
	
}
