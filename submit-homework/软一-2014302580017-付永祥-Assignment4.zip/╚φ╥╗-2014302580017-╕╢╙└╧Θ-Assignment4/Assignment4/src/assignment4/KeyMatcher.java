package assignment4;

public class KeyMatcher {
	private String[] keys;
	private boolean hasEmail = false;
	private boolean hasPhone = false;
	private int indexOfEmail,indexOfPhone;
	
	public KeyMatcher(String keys[]){
		this.keys = keys;
		//�洢Сд�����ڱȽ�
		for(int i=0;i<this.keys.length;i++)
			this.keys[i] = this.keys[i].toLowerCase();
		
		hasEmail();
		hasPhone();
	}
	
	public boolean match(ProfessorInfo pi){
		if(hasPhone){
			String phone = pi.getPhone();
			if(phone.replace("+", "").replace("-", "").contains(keys[indexOfPhone].replace("+", "").replace("-", "")))
				return true;
		}
		
		if(hasEmail){
			String email = pi.getEmail();
			if(email.contains(keys[indexOfEmail]))
				return true;
		}
		
		String educationBackground = pi.getEducationBackground();
		String researchInterests = pi.getResearchInterests();
		String name = pi.getName();
		
		for(String key:keys){
			if(name.toLowerCase().contains(key)) return true;
			if(researchInterests.toLowerCase().contains(key)) return true;
			if(educationBackground.toLowerCase().contains(key)) return true;
		}
		
		return false;
	}
	
	private boolean hasEmail(){
		String regex = "\\w+@.+";
		for(int i=0;i<keys.length;i++)
			if(keys[i].matches(regex)){
				hasEmail = true;
				indexOfEmail = i;
				break;
			}
		return hasEmail;
	}
	
	private boolean hasPhone(){
		String regex = "[0-9-+]{5,16}"; //���ų����
		for(int i=0;i<keys.length;i++)
			if(keys[i].matches(regex)){
				hasPhone = true;
				indexOfPhone = i;
				break;
			}
		return hasPhone;
	}
}
