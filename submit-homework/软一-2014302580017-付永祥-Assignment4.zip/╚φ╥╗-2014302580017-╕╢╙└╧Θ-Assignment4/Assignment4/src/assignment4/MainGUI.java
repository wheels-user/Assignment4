package assignment4;

import java.awt.EventQueue;
import java.awt.ScrollPane;

import javax.swing.JFrame;
import javax.management.relation.RelationServiceNotRegisteredException;
import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JLabel;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.awt.Font;

public class MainGUI {

	private JFrame frame;
	private JTextField txtfKeyword;
	private JTextArea txtrResult;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainGUI window = new MainGUI();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainGUI() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 872, 601);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JButton btnSearch = new JButton("Search");
		btnSearch.addMouseListener(new MouseAdapter() {
			@Override
			public void mouseClicked(MouseEvent e) {
				String[] keys = txtfKeyword.getText().trim().split(" {1,}");
				Engine engine = new Engine(keys);
				
				ArrayList<ProfessorInfo> result = engine.search();
				
				txtrResult.setText("");
				for(ProfessorInfo item:result){
					txtrResult.append(item.toString()+"\n\n");
					//�������ķָ���
					txtrResult.append("-----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n");

				}
				if(result.isEmpty()){
					txtrResult.setText("��ѽ��û�ѵ����뻻���ؼ�������");
				}
				txtrResult.setCaretPosition(0);
				
			}
		});
		btnSearch.setBounds(659, 59, 113, 36);
		frame.getContentPane().add(btnSearch);
		
		txtfKeyword = new JTextField();
		txtfKeyword.setFont(new Font("����", Font.PLAIN, 30));
		txtfKeyword.setBounds(87, 60, 523, 35);
		frame.getContentPane().add(txtfKeyword);
		txtfKeyword.setColumns(10);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(87, 140, 685, 365);
		frame.getContentPane().add(scrollPane);
		
		txtrResult = new JTextArea();
		txtrResult.setFont(new Font("Monospaced", Font.PLAIN, 20));
		txtrResult.setEditable(false);
		txtrResult.setAutoscrolls(false);
		scrollPane.setViewportView(txtrResult);
		
		JLabel lblKeyword = new JLabel("keyword");
		lblKeyword.setBounds(88, 35, 72, 18);
		frame.getContentPane().add(lblKeyword);
		
		JLabel lblResult = new JLabel("Result");
		lblResult.setBounds(87, 121, 72, 18);
		frame.getContentPane().add(lblResult);
	}
}
