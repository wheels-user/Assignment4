package assignment4;

import java.sql.*;
import java.util.ArrayList;

public class AccessDB {
	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://127.0.0.1:3306/my_schema";
	
	// Database credentials
	static String USER = "root";
	static String PASS = "123456";

	private Connection conn = null;
	private Statement stmt = null;
	
	public AccessDB(){
		init();
	}
	
	public ResultSet getAllResoure(){
		String sql = "select * from 2014302580017_professor_info;";
		ResultSet rs = null;
		try {
			rs = stmt.executeQuery(sql);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return rs;
	}
	
	public void close(){
		
			try {
				if(stmt != null) stmt.close();
				if(conn != null) conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		
	}

	private void init() {

		try {
			// STEP 1: Register JDBC driver
			Class.forName("com.mysql.jdbc.Driver");

			// STEP 2: Open a connection
			//System.out.println("DataBase: Connecting to database...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			// STEP 3: Execute a query
			//System.out.println("DataBase: Creating statement...");
			stmt = conn.createStatement();
			

		} catch (SQLException se) {
			// Handle errors for JDBC
			se.printStackTrace();
		} catch (Exception e) {
			// Handle errors for Class.forName
			e.printStackTrace();
		} 
		//System.out.println("DataBase: Goodbye!");

	}
}
