package assignment4;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.spi.DirStateFactory.Result;

public class Engine {
	private String[] keys;
	private AccessDB adb;
	private static String[] uselessWords = {"a","an","the","in","on","under","of","is","and","are","but"};

	public Engine(String[] keys) {
		this.keys = eliminate(keys);
		adb = new AccessDB();
	}
	
	public String[] getKeys(){
		return keys;
	}

	public ArrayList<ProfessorInfo> search() {
		ArrayList<ProfessorInfo> al = new ArrayList<ProfessorInfo>();
		
		KeyMatcher km = new KeyMatcher(keys);
		
		try {
			ResultSet rs = adb.getAllResoure();
			while(rs.next()){
				String name = rs.getString("name");
				String educationBackground = rs.getString("educationBackground");
				String researchInterests = rs.getString("researchInterests");
				String email = rs.getString("email");
				String phone = rs.getString("phone");
				ProfessorInfo pi = new ProfessorInfo(name, educationBackground, researchInterests, email, phone);
				
				if(km.match(pi))
					al.add(pi);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		al = sort(al);
		adb.close();

		return al;
	}
	
	private String[] eliminate(String[] keys){
		String[] result;
		int i = 0,length = keys.length;
//		for(String key:keys){ //for each �ǷǱ䶯���㷨,�����޸����е�ֵ!!!!!
		for(int j=0;j<keys.length;j++){
			for(String uselessWord:uselessWords){
				if(keys[j].equals(uselessWord)){
					keys[j] = null;
					
					length--;
					break;
				}
			}
		}
		
		
		result = new String[length];
		for(String key:keys){
			if(key!=null && !key.isEmpty()){
				result[i] = key;
				i++;
			}
		}
		
		return result;
	}
	
	private ArrayList<ProfessorInfo> sort(ArrayList<ProfessorInfo> al){
		al.sort(new TFComparator(keys));
		return al;
	}
}
